#include "stm32f10x.h"                  // Device header
#include "Delay.h"                      //延时
#include "OLED.h"                       //显示屏
#include "Motor.h"                      //电机
#include "servo.h"                      //舵机
#include "Grey.h"                       //灰度
#include "Serial.h"                     //串口
#include "Pid.h"                        //方向环
#include "Pid2.h"                       //速度环
#include "Encoder.h"                    //编码器
#include "Key.h"                        //按键
#include "Timer.h"                      //定时器初始化
//#include "Buzzer.h"                   //声光显示

float Z ;                  //定义偏航角
float targetAngle = 96.0f; //定义目标角度
PID_TypeDef pidController; //定义方向环pid结构体
PID2_TypeDef pidController2 ; //定义速度环结构体
static uint8_t KeyNum;	   //定义用于接收按键键码的变量
int16_t Angle;		       //定义角度变量
float Setspeed;		       //定义电机速度
float speed;               //瞬时速度
int16_t aaa;               //aaa为每0.05秒(可调)，旋转编码器脉冲增量
float bbb;                 //bbb为每0.05秒(可调)，轮子驶过的距离
float time ;               //运行时间

uint8_t pressCount = 0;//按键次数
int D = 1;//题目数
int e = 0;//调节触发pid范围
int t = 0;//调节触发pid范围
	


//作者：环戊二烯   2024/10/20
//B站：径向合力提供向心力
//欢迎交流！共同进步！

int main(void)//合理使用，开源为了分享思路，理解远远比copy重要（本人小白，代码稍显啰嗦，各位佬们图个乐子就好）
{
	//模块初始化
	OLED_Init();		   //OLED初始化
	Motor_Init();		   //直流电机初始化
	Servo_Init();          //舵机初始化
	Grey_Init();           //灰度初始化
	Serial_Init();         //串口初始化
	Encoder_Init() ;       //编码器初始化
	Key_Init();			   //按键初始化
	Timer_Init();          //定时器初始化
	Buzzer_Init();         //声光显示初始化
	PID_Init( &pidController, 0.8, 0, 0.05);//pid初始化（调舵机）舵机闭环
	PID2_Init(&pidController2, 0.8, 0, 0.05);//pid2初始化（调电机）电机闭环
	
	/*显示静态字符串*/
	OLED_ShowString(1, 1, "Setspeed:");		//1行1列显示速度
	OLED_ShowString(2, 1, "angle:");		//2行1列显示角度
	OLED_ShowString(3, 1, "Speed:");	    //3行1列显示编码器速度
	OLED_ShowString(4, 1, "length:");       //4行1列显示行驶长度
	
	
	/*初始值设定*/
	Angle = 96;//舵机中值
    Servo_SetAngle(Angle);
	Setspeed = 0.7;					//速度设置m/s
    OLED_ShowSignedNum(1, 10, Setspeed, 3);	//OLED显示速度变量,100为极限值
    GPIO_SetBits(GPIOC, GPIO_Pin_15);//为按键所设置

           
while (1)
	{	  
		if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_14) == 1)			//读PC14输入寄存器的状态，如果为1则表示按键按下
	   {
                   Delay_ms(80);
		   pressCount = pressCount+1;
		   		   Delay_ms(800);											//延时消抖	
	   }

		   if(length > 0.001 )//使用编码器测距作为激活开关
{			
		 Delay_s(1);
	  switch (pressCount)
	  {  
 
		  
		  
		  case 1://题1
                 length = 0;
                 Enable_Buzzer();		  
				 Delay_s(1);
			for(;;)
	    	   {
	             Apply_PID1_To_Servo(&pidController, targetAngle, Z);
				 Apply_PID_To_Motor(&pidController2, Setspeed, speed);
                              Get_Station_grey();
                			 if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1  )
	              	 {
	              	   Motor_SetSpeed(0);
	              	   Enable_Buzzer();
	              	   Delay_s(1);
					   break;
	              	 }	 
			   }
		    length = 0;
            break;			   
					 
			   
			   
		 

		  case 2://题2
			     length = 0;
	              Enable_Buzzer();
			      Delay_s(1);
		          for(;;)//A点开始执行
	                   {   
						   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
		        		   Apply_PID1_To_Servo(&pidController, targetAngle, Z);
                           Get_Station_grey();
		        		   if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1 )  
	                    	 {
	                    	   Enable_Buzzer();
		        			   break;
	                    	 } 					 
		        	     }
	              for(;;)//B点
	              	 {   
						 Control_Servo_Based_on_Sensors_BC();//BC
						 Apply_PID_To_Motor(&pidController2, Setspeed, speed);
		        			  if(length > 2.29 )  //到C点
	                    	 {
	                    	   Enable_Buzzer();
		        			   break;
	                    	 } 
	              	 }	
                  for(;;)//C点
	                   {    Apply_PID_To_Motor(&pidController2, Setspeed, speed);
						    Apply_PID2_To_Servo(&pidController, targetAngle, Z);
                            Get_Station_grey();
		        		   if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1  )  
	                    	 {
	                    	   Enable_Buzzer();
		        			   break;
	                    	 } 					 
		        	     }	
                  for(;;)//D点
	              	 {   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
	              	     Control_Servo_Based_on_Sensors_2_DA();//DA
		        			  if(length > 4.47   ) //到A停止 
	                    	 {
	                    	   Motor_SetSpeed(0);  
	                    	   Enable_Buzzer();
	                    	   Delay_s(1);
		        			   break;
	                    	 } 
	              	 }
            length = 0;					 
            break;	

					
					 
		 


		  case 3://题3
			   length = 0;
		         Enable_Buzzer();
                 Delay_s(1);
		          for(;;)//A点开始执行
	                     {
						   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
		        		   Apply_PID1_To_Servo(&pidController, targetAngle, Z);
                           Get_Station_grey();
						   if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1 )
						  {
									   Enable_Buzzer();
									   break;
				     	  }								  
	                     } 					 
		        	   
	              for(;;)//C点
	              	 {
					   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
	              	   Control_Servo_Based_on_Sensors_CB();
						 if(length > 2.8)
						 {
						  Enable_Buzzer();
		        		   break;
						 }
	              	 }	
					 
                  for(;;)//B点
	                   {
						   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
						   Servo_SetAngle(112);//打角
						   
						   if(Z<=3)
						   {  
							   Servo_SetAngle(96);//回正
							   for(;;)
							   {  
								   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
							      Apply_PID3_To_Servo(&pidController, targetAngle, Z);
                                  Get_Station_grey();
								     if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1 )  
	                    	 {
	                    	   Enable_Buzzer();
		        			   break;
	                    	 }
							   }
							 break;
						   }
						   
		        		   					 
		        	     }	
                  for(;;)//D点
	              	 {
	              	   Control_Servo_Based_on_Sensors_DA();
		        			  if(length > 5.34 )  
	                    	 {
	                    	   Motor_SetSpeed(0);  //到A停止
	                    	   Enable_Buzzer();
	                    	   Delay_s(1);
		        			   break;
	                    	 } 
	              	 }
			    length = 0;
                break;


           
				 
	
	         

		  case 4://题4
				  length = 0;
			      Enable_Buzzer();
				  Delay_s(1);
				for(;;)
			{	
				if( D <= 4)
			  {   	
				  for(;;)//A点开始执行
	                     {
						   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
		        		   Apply_PID1_To_Servo(&pidController, targetAngle, Z);
                           Get_Station_grey();
						   if(A4==1 || A5==1 || A12==1 || A15==1 || B13==1
							   || A8==1 || B15==1 || B14==1 )
						  {
									   Enable_Buzzer();
									   break;
				     	  }								  
	                     } 					 
		        	//Servo_SetAngle(108);  //辅助进入循迹 
	              for(;;)//C点
	              	 {
					   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
	              	   Control_Servo_Based_on_Sensors_CB();

						 if(length > 2.8)
						 {
							 
						  Enable_Buzzer();
		        		   break;
						 }
	              	 }	
					 
                  //B点
	                   
						   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
						   Servo_SetAngle(121);//打角
						   Delay_ms(400);
					 for(;;)
					 {
						   Servo_SetAngle(82);//打角
						   if(Z <= 2+t )
						   {  
							   for(;;)
							   {  
								   Apply_PID_To_Motor(&pidController2, Setspeed, speed);
							      Apply_PID3_To_Servo(&pidController, targetAngle, Z);
								   Get_Station_grey();
								     if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 || B14==1)  
	                    	 {
							//Servo_SetAngle(93);  //辅助进入循迹
	                    	   Enable_Buzzer();
		        			   break;
	                    	 }
							   }
							   t += 8;
							 break;
						   } 					 
		        	  }  	
					    
                  for(;;)//D点
	              	 {
	              	   Control_Servo_Based_on_Sensors_DA();
		        			  if(length > 5.5 )  
	                    	 {
	                    	   Enable_Buzzer();
							   length = 0;
								 if(D==4)
								 {
								  Motor_SetSpeed(0);
				                 break;
								 }
							for(;;)
						{		 
							Servo_SetAngle(84);//打角
								 if( Z <= 96 + e)
								 {
									 break; 
								 }
						}
						e += 2;
						break;
	                    	 } 
	              	 }				 
	              D++;				 
			 }
			else if(D > 4)
{
	    break;
}	
		  }
			length = 0;
			  break;
	 }
			 
length = 0;
    }
  }
}







/**
  * 函    数：USART1中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  *           函数名为预留的指定名称，可以从启动文件复制
  *           确保函数名正确，不能有任何差异，否则中断函数将不能进入请
  */
//陀螺仪串口协议解析，用于处理从USART1接收到的据
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET) 
	{
        static unsigned char index = 0;
        static unsigned char buffer[16];
        unsigned char check = 0;
        int i;
        buffer[index++] = USART_ReceiveData(USART1);
        switch (index) 
		{
            case 2:
                if (buffer[0] == 0x55 && buffer[1] == 0x53) 
				{	
                } 
				else 
				{
                    index = 0;
                }
                break;
            case 11:
                for (i = 0; i < 10; i++) {
                    check += buffer[i];
                }
                if (check == buffer[index - 1]) {
                    Z = (short)((buffer[7] << 8) + buffer[6]);
                    Z = Z / 32768.0f * 180+96 ;
                    index = 0;
                } else {
                    index = 0;
                }
                break;
            default:
                break;
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); // 清除USART1的RXNE标志位
    }
}
  
   

void TIM4_IRQHandler(void)//50ms一次中断，用于编码器
{
	
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
		 OLED_ShowNum(2,14,pressCount,1);
		 OLED_ShowNum(2, 7, Z, 4);               //显示偏航角
         OLED_ShowFNum(3, 7, speed, 6,3);
		 OLED_ShowFNum(4, 8, length, 6,3);
		aaa = Encoder_Get();
		time += 0.05;
		speed = aaa*0.00016*20;//(瞬时速度)每秒
		length += speed*0.05;//每0.05秒长度增量
		
		
		
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);

		
	}	
		
}		


