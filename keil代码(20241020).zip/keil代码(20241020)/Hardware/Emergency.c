#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "servo.h"
#include "Grey.h"
#include "Station.h"
#include "Emergency.h"

int emergency_station()
{
        uint8_t sensorA8_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A8);
		uint8_t sensorA4_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A4);
	    uint8_t sensorA5_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A5);

        uint8_t sensorB8_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B8);
        uint8_t sensorB9_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_B9);
        uint8_t sensorB12_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B12);
        uint8_t sensorB13_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B13);
        uint8_t sensorB14_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B14);
        uint8_t sensorB15_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B15);
	if(sensorA8_status == Bit_RESET && sensorB8_status == Bit_RESET && sensorB9_status == Bit_RESET &&  sensorB13_status == Bit_RESET && sensorB14_status == Bit_RESET && sensorB15_status == Bit_RESET 
		&& sensorA5_status == Bit_RESET && sensorA4_status == Bit_RESET)
    {
	    return 1;
    }
	else
    {
		return 0;
    }

}
	
void stop_now()//紧急状态立刻停止函数！
  {
	  if(emergency_station()==1)
	  {
		   int Speed = 0;
		   Motor_SetSpeed(Speed);
	  }
  }
