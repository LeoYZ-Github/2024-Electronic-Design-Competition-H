#ifndef __EMERGENCY_H

#define GREY_SENSOR_PORT_A GPIOA
#define GREY_SENSOR_PIN_A8 GPIO_Pin_8
#define GREY_SENSOR_PIN_A4 GPIO_Pin_4
#define GREY_SENSOR_PIN_A5 GPIO_Pin_5

#define GREY_SENSOR_PORT_B GPIOB
#define GREY_SENSOR_PIN_B8 GPIO_Pin_8
#define GREY_SENSOR_PIN_B9 GPIO_Pin_9
#define GREY_SENSOR_PIN_B12 GPIO_Pin_12
#define GREY_SENSOR_PIN_B13 GPIO_Pin_13
#define GREY_SENSOR_PIN_B14 GPIO_Pin_14
#define GREY_SENSOR_PIN_B15 GPIO_Pin_15

int emergency_station();
void stop_now();
#endif 
