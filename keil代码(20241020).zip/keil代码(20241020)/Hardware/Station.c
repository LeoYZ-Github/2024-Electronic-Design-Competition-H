#include "stm32f10x.h"                  // Device header
#include "grey.h"
#include "PWM.h"
#include "servo.h"
#include "Motor.h"
#include "station.h"
#include "Emergency.h"

static int stop=0;  //定义状态变量
int state_flag_before = 0, state_flag_now = 0;
int Num=0;
int state_B=0,state_C=0,state_A=0;

void Stop_Servo_Based_on_Sensors(void) 
	{

	uint8_t sensorA8_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A8);
	uint8_t sensorA4_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A4);
	uint8_t sensorA5_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A5);
 	uint8_t sensorA12_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A12);
 	uint8_t sensorA15_status =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A15);

    uint8_t sensorB13_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B13);
    uint8_t sensorB14_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B14);
    uint8_t sensorB15_status = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B15);

	
    if(sensorA8_status == Bit_RESET || sensorA15_status == Bit_RESET || sensorA12_status == Bit_RESET
		||  sensorB13_status == Bit_RESET || sensorB14_status == Bit_RESET || sensorB15_status == Bit_RESET 
		|| sensorA5_status == Bit_RESET || sensorA4_status == Bit_RESET) 
		
	{
    state_flag_before = state_flag_now;
    state_flag_now = 1;
    } 
	else {
    state_flag_before = state_flag_now;
    state_flag_now = 0;
}
	
	 
	 if(state_flag_before==0&&state_flag_now==1)
	 {	
     		 state_B=1;//B	 
		 
	 }
	if(state_flag_before==1&&state_flag_now==0)
	 {	
		 Num++;
		 if(Num==1)
		 {	 
     		 state_C=1;//C
		 }
		     
		 if(Num==2)
		 {
      state_A=1;//A
		 }			 
	 }
  
 if(state_A==1)
		 {
      Motor_SetSpeed(0);
		 }	
	 
	 
	 
	 

}

