#ifndef __TIM1_H
#define __TIM1_H

void TIM1_Init(void);

#endif
