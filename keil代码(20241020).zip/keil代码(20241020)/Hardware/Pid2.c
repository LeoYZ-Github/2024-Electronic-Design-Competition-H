#include "Pid2.h"
#include "Motor.h"  


void PID2_Init(PID2_TypeDef* pid, float Kp, float Ki, float Kd)
	{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Current_Error=0;//当前误差
    pid->Last_Error=0;//上一次误差
    pid->Previous_Error=0;//上上次误差
//	pid->integral=0;
    }



//增量式PID电机控制
float PID_Increase(PID2_TypeDef*pid, float Point , float NowPlace )
{
   float iError ; //当前误差
   float Increase; //最后得出的实际增量

   iError = Point - NowPlace; // 计算当前误差
 //  pid->integral += iError;
   Increase =  pid->Kp * iError + pid->Ki * iError + pid->Kd * (iError -  pid->Last_Error) ;

  pid->Previous_Error = pid->Last_Error; // 更新前次误差
  pid->Last_Error = iError;              // 更新上次误差
  return Increase;                       // 返回增量
}


	void Apply_PID_To_Motor(PID2_TypeDef* pid, float Point,float NowPlace ) //如何测出当前的车速？
{

    float controlValue = PID_Increase( pid, NowPlace, Point);
    
    float pwm = 250 - controlValue*9 ; 
    Motor_SetSpeed(pwm);
    	
}
