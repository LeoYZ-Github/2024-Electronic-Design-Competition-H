#include "Pid.h"
#include "servo.h" 
#include "Motor.h"                  

float controlValue;

//PID初始化
void PID_Init(PID_TypeDef* pid, float Kp, float Ki, float Kd)
	{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->integral = 0.0f;
    pid->prevError = 0.0f;
    }



float PID1_Calc(PID_TypeDef* pid, float setpoint, float measuredValue)
	{
    
	float error = setpoint - measuredValue;
    pid->integral += error;
    float derivative = error - pid->prevError;
    float output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
    pid->prevError = error;
    return output;
	}
	
	
float PID2_Calc(PID_TypeDef* pid, float setpoint, float measuredValue)
	{
    
//    pid->integral += error;
		if (measuredValue  >178.0f) 
		{
       measuredValue= measuredValue -178.0f; 
        } 
		else // (measuredValue > 70.0f && measuredValue <= 83) 
		{
       measuredValue= measuredValue + 177.0f; 
        } 
	float error = setpoint - measuredValue;
    float derivative = error - pid->prevError;
    float output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
    pid->prevError = error;
    return output;
	}
float PID3_Calc(PID_TypeDef* pid, float setpoint, float measuredValue)
	{
    
//    pid->integral += error;
		if (measuredValue  < 96.0f) 
		{
       measuredValue= measuredValue + 96.0f; 
        } 
	float error = setpoint - measuredValue;
    float derivative = error - pid->prevError;
    float output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
    pid->prevError = error;
    return output;
	}
	
	
//跑96度直线
void Apply_PID1_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue) 
	{

    float controlValue1 = PID1_Calc(pid, setpoint, measuredValue);
    
    float Angle = 96 + controlValue1;
    
    
   
    if (Angle < 71.0f)
		{
        Angle = 71.0f; 
        }
	else if (Angle > 121.0f) 
		{
        Angle = 121.0f; 
        }

    
        Servo_SetAngle(Angle); 
		
   }
	
   
 //（第三题从B到D点）  
void Apply_PID2_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue) 
	{

    float controlValue2 = PID2_Calc(pid, setpoint, measuredValue);
    
    float Angle = 96 + controlValue2;
    
    
   
    if (Angle < 71.0f)
		{
        Angle = 71.0f; 
        }
	else if (Angle > 121.0f) 
		{
        Angle = 121.0f; 
        }

    
        Servo_SetAngle(Angle); 
		
   }
	
   
   
   
	void Apply_PID3_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue) 
	{

    float controlValue3 = PID3_Calc(pid, setpoint, measuredValue);
    
    float Angle = 93 + controlValue3;
    
    
   
    if (Angle < 71.0f)
		{
        Angle = 71.0f; 
        }
	else if (Angle > 121.0f) 
		{
        Angle = 121.0f; 
        }

    
        Servo_SetAngle(Angle); 
		
   }


   

