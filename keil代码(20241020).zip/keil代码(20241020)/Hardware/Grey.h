#ifndef __GREY_H
#define __GREY_H

#define GREY_SENSOR_PORT_A GPIOA
#define GREY_SENSOR_PIN_A8 GPIO_Pin_8
#define GREY_SENSOR_PIN_A4 GPIO_Pin_4
#define GREY_SENSOR_PIN_A5 GPIO_Pin_5
#define GREY_SENSOR_PIN_A12 GPIO_Pin_12
#define GREY_SENSOR_PIN_A15 GPIO_Pin_15

#define GREY_SENSOR_PORT_B GPIOB
#define GREY_SENSOR_PIN_B13 GPIO_Pin_13
#define GREY_SENSOR_PIN_B14 GPIO_Pin_14
#define GREY_SENSOR_PIN_B15 GPIO_Pin_15


extern uint8_t A8 ;
extern uint8_t A4 ;
extern uint8_t A5 ;
extern uint8_t A12;
extern uint8_t A15;

extern uint8_t B13;
extern uint8_t B14;
extern uint8_t B15;

extern float length;              //运行距离

void Grey_Init(void);
void Get_Station_grey(void);
void Control_Servo_Based_on_Sensors_CB(void);
void Control_Servo_Based_on_Sensors_DA(void);
void Control_Servo_Based_on_Sensors(void);
void Control_Servo_Based_on_Sensors_BC(void);
void Control_Servo_Based_on_Sensors_2_DA(void);
#endif 
