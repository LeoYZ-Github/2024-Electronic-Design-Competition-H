#ifndef PID_H
#define PID_H

typedef struct {
    float Kp; // Proportional gain
    float Ki; // Integral gain
    float Kd; // Derivative gain
    float integral;
    float prevError;
} PID_TypeDef;

void PID_Init(PID_TypeDef* pid, float Kp, float Ki, float Kd);
float PID1_Calc(PID_TypeDef* pid, float setpoint, float measuredValue);
float PID2_Calc(PID_TypeDef* pid, float setpoint, float measuredValue);
float PID3_Calc(PID_TypeDef* pid, float setpoint, float measuredValue);
void Apply_PID1_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue);
void Apply_PID2_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue);
void Apply_PID3_To_Servo(PID_TypeDef* pid, float setpoint, float measuredValue);


float Map_ControlValueToAngle(float controlValue);
#endif // PID_H


