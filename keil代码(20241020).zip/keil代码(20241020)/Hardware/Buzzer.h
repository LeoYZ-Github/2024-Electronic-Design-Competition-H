#ifndef __BUZZER_H
#define __BUZZER_H


void Buzzer_Init(void)；
void Enable_Buzzer(void);

#endif
