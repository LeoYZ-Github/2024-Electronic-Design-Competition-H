#ifndef PID2_H
#define PID2_H

typedef struct {
    float Kp; // Proportional gain
    float Ki; // Integral gain
    float Kd; // Derivative gain
    float Current_Error;
    float Last_Error;
	float Previous_Error;
//	float integral;
} PID2_TypeDef;

void PID2_Init(PID2_TypeDef* pid, float Kp, float Ki, float Kd);
float PID_Increase(PID2_TypeDef*pid,float Point , float NowPlace);
void Apply_PID_To_Motor(PID2_TypeDef* pid, float NowPlace, float Point); 

#endif // PID2_H
