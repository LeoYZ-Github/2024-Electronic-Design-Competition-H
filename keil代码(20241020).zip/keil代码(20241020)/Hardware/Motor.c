#include "stm32f10x.h"                  // Device header
#include "PWM.h"



//函    数：直流电机初始化 ； 参    数：无 ；返 回 值：无
void Motor_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB10和PB11引脚初始化为推挽输出，两者分别对应1DIR与2DIR
	
	PWM1_Init();													//初始化直流电机的底层PWM
}


//函    数：直流电机设置速度 ； 参    数：Speed 要设置的速度，范围：-100~100 ； 返 回 值：无
void Motor_SetSpeed(float pwm) 
{
						//如果设置正转的速度值
	
	
		GPIO_WriteBit(GPIOB,  GPIO_Pin_10,Bit_RESET ); //1号电机正转
		

		PWM_SetCompare1(pwm);				//PWM设置为速度值，对speed进行加减可以控制电机1的速度
		
			GPIO_WriteBit(GPIOB,  GPIO_Pin_11,Bit_RESET ); //2号电机正转
	
		PWM_SetCompare2(pwm);				//PWM设置为速度值，对speed进行加减可以控制电机2的速度
	
	
}
