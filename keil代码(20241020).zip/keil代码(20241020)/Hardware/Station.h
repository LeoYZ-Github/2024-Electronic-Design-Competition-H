#ifndef __STATION_H
#define __STATION_H

#define GREY_SENSOR_PORT_A GPIOA
#define GREY_SENSOR_PIN_A8 GPIO_Pin_8
#define GREY_SENSOR_PIN_A4 GPIO_Pin_4
#define GREY_SENSOR_PIN_A5 GPIO_Pin_5
#define GREY_SENSOR_PIN_A12 GPIO_Pin_12
#define GREY_SENSOR_PIN_A15 GPIO_Pin_15

#define GREY_SENSOR_PORT_B GPIOB
#define GREY_SENSOR_PIN_B13 GPIO_Pin_13
#define GREY_SENSOR_PIN_B14 GPIO_Pin_14
#define GREY_SENSOR_PIN_B15 GPIO_Pin_15




extern uint8_t sensorA8_status;
extern uint8_t sensorA4_status;
extern uint8_t sensorA5_status;
extern uint8_t sensorA12_status;
extern uint8_t sensorA15_status;


extern uint8_t sensorB14_status;
extern uint8_t sensorB15_status;
extern uint8_t sensorB13_status;




uint8_t Grey_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);



void Stop_Servo_Based_on_Sensors(void);

#endif 

