#include "stm32f10x.h"                  // Device header
#include "Grey.h"
#include "PWM.h"
#include "servo.h"
#include "Motor.h"
#include "delay.h"

uint8_t A8 ;
uint8_t A4 ;
uint8_t A5 ;
uint8_t A12;
uint8_t A15;

uint8_t B13;
uint8_t B14;
uint8_t B15;

float length;              //运行距离

uint8_t bitstatus = 0x00;

void Grey_Init(void)//初始化灰度
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
   
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_12 | GPIO_Pin_15 ; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}



	uint8_t Grey_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin) //检查引脚状态函数
{
    if ((GPIOx->IDR & GPIO_Pin) != (uint32_t)Bit_RESET) 
		{
        bitstatus = (uint8_t)Bit_SET;
        } 
		else 
		{
        bitstatus = (uint8_t)Bit_RESET;
        }
        return bitstatus;
}

void Get_Station_grey(void)//读取灰度状态
{
    A8 =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A8);
    A4 =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A4);
    A5 =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A5);
    A12 =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A12);
    A15 =  Grey_ReadInputDataBit(GREY_SENSOR_PORT_A, GREY_SENSOR_PIN_A15);
   
    B13 = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B13);
    B14 = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B14);
    B15 = Grey_ReadInputDataBit(GREY_SENSOR_PORT_B, GREY_SENSOR_PIN_B15);
}


 void Control_Servo_Based_on_Sensors_CB(void)//循迹（C到B点）
 {  
	  //Servo_Init();	

  Get_Station_grey();

	 
	 if (  A8==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(96);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 ||length > 2.8)
		   {
	          break;
		   }
	     //  Delay_ms(25);
       } 
}
		
if (  A15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(103);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A8==1 || B13==1 || B14==1 || B15==1 || length > 2.8 )
		   {
	          break;
		   }
	      // Delay_ms(25);
       } 
}

if (  A12==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(107);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A8==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.8)
		   {
	          break;
		   }
	    //   Delay_ms(25);
       } 
}		
		
if (  A5==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(121);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A8==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.8)
		   {
	          break;
		   }
	    //   Delay_ms(25);
       } 
}

if (  B13==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(91);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || A8==1 || B14==1 || B15==1 || length > 2.8)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  B14==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(85);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 || length > 2.8 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}
		
if (  B15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(80);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || A8==1 || length > 2.8)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  A4==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(71);			// 中间A8
			Get_Station_grey();
		   if( A8==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.8)
		   {
	          break;
		   }
	  //     Delay_ms(25);
       } 
}

}
 
void Control_Servo_Based_on_Sensors_DA(void)//循迹（D到A点）
{  	

  Get_Station_grey();

	 
	 if (  A8==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(96);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 ||length > 5.5)
		   {
	          break;
		   }
	    //   Delay_ms(25);
       } 
}
		
if (  A15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(103);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A8==1 || B13==1 || B14==1 || B15==1 || length > 5.5 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  A12==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(107);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A8==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 5.5)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}		
		
if (  A5==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(121);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A8==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 5.5)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  B13==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(91);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || A8==1 || B14==1 || B15==1 || length > 5.5)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  B14==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(85);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 || length > 5.5 )
		   {
	          break;
		   }
	  //     Delay_ms(25);
       } 
}
		
if (  B15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(80);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || A8==1 || length > 5.5)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  A4==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(71);			// 中间A8
			 Get_Station_grey();
		   if( A8==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 5.5)
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}


}


	 



void Control_Servo_Based_on_Sensors(void)  //循迹（C到B点）
{  	

  Get_Station_grey();

	 
	 if (  A8==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(96);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	    //   Delay_ms(25);
       } 
}
		
if (  A15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(103);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A8==1 || B13==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	    //   Delay_ms(25);
       } 
}

if (  A12==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(107);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A8==1 || A15==1 || B13==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}		
		
if (  A5==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(121);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A8==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  B13==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(91);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || A8==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	  //     Delay_ms(25);
       } 
}

if (  B14==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(85);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 )
		   {
	          break;
		   }
	  //     Delay_ms(25);
       } 
}
		
if (  B15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(80);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || A8==1 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}

if (  A4==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(71);			// 中间A8
			 Get_Station_grey();
		   if( A8==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 )
		   {
	          break;
		   }
	   //    Delay_ms(25);
       } 
}


}


void Control_Servo_Based_on_Sensors_BC(void)//循迹（B到C点） 
 {  
	  	

  Get_Station_grey();

	 
	 if (  A8==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(96);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 ||length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}
		
if (  A15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(103);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A8==1 || B13==1 || B14==1 || B15==1 || length > 2.29 )
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  A12==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(107);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A8==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}		
		
if (  A5==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(121);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A8==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  B13==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(91);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || A8==1 || B14==1 || B15==1 || length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  B14==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(85);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 || length > 2.29 )
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}
		
if (  B15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(80);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || A8==1 || length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  A4==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(71);			// 中间A8
			 Get_Station_grey();
		   if( A8==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 2.29)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

}
 

void Control_Servo_Based_on_Sensors_2_DA(void) //（2题D到A）
 {  
	  //Servo_Init();	

  Get_Station_grey();

	 
	 if (  A8==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(96);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 ||length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}
		
if (  A15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(103);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A8==1 || B13==1 || B14==1 || B15==1 || length > 4.52 )
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  A12==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(107);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A8==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}		
		
if (  A5==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(121);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A8==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 ||length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  B13==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(91);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || A8==1 || B14==1 || B15==1 ||length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  B14==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(85);			// 中间A8
			Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || A8==1 || B15==1 || length > 4.52 )
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}
		
if (  B15==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(80);			// 中间A8
			 Get_Station_grey();
		   if( A4==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || A8==1 || length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

if (  A4==1 ) 
{
       for(;;)
       {
			Servo_SetAngle(71);			// 中间A8
			 Get_Station_grey();
		   if( A8==1 || A5==1 || A12==1 || A15==1 || B13==1 || B14==1 || B15==1 || length > 4.52)
		   {
	          break;
		   }
	       Delay_ms(25);
       } 
}

}



